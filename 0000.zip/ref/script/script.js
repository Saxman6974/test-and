$(document).ready(function()
{
    $("#lower div ul li").click(function(){
        var list = $(this).index();
        $("#main > div").hide();
        $("#main > div").eq(list).show();
    });
    $("#l_S .closeB").click(function()
    {
        $("#l_S").hide();
    });
});